> 교육용 가상 자료 — 스킬 샘플 참고 파일. 예시 수치·색상은 가상 회사 (주)한빛정밀 기준이며 실제 기업과 무관합니다.

# 스타일 토큰 (CI 교체용)

수강생은 아래 HEX 값만 자기 회사 CI 색상으로 바꾸면 된다. 이름(primary 등)은 바꾸지 않는다.

## 색상
| 토큰 | HEX | 용도 |
|---|---|---|
| primary | #1F3B66 | 제목, 표 머리글, 주요 막대 |
| accent | #1D6FE0 | 강조 수치, 우리 회사 데이터 |
| alert | #C0392B | 위험, 미달, 감소 |
| gray-dark | #4A4A4A | 본문 |
| gray-mid | #9AA0A6 | 비교 대상 |
| gray-light | #EEF1F5 | 배경 박스, 표 줄무늬 |
| white | #FFFFFF | 배경 |

## CSS 변수 (아티팩트용)
```css
:root {
  --primary: #1F3B66;
  --accent: #1D6FE0;
  --alert: #C0392B;
  --gray-dark: #4A4A4A;
  --gray-mid: #9AA0A6;
  --gray-light: #EEF1F5;
  --bg: #FFFFFF;
  --font: "Pretendard", "Malgun Gothic", "맑은 고딕", sans-serif;
}
```

## 글꼴
- 1순위 Pretendard / 대체 맑은 고딕
- PPT: 제목 24pt 굵게, 본문 14~16pt, 주석 10pt
- Word: 제목 16pt, 본문 11pt, 표 10pt

## 로고
- 파일: references/logo.png (가로형, 투명 배경 권장)
- 위치: PPT 오른쪽 위 / Word 머리글 왼쪽, 높이 1cm 이하
